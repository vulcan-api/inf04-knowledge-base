﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace ArkuszCezar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
                
                InitializeComponent();
            
        }
        void zaszyfruj(object sender, RoutedEventArgs e)
        {
            string StrKlucz = TBklucz.Text;
            int klucz;
            if (TBklucz.Text.Length <= 0)
            {
                 
                klucz = 0;
            }
            else
            {
                klucz = Convert.ToInt32(StrKlucz);
            }
                string tekst = TBtekst.Text;
            TBszyfr.Text = Szyfruj(tekst, klucz);
        }
        public static string Szyfruj(string tekst, int klucz)
        {
            klucz = klucz % 26; //klucz z przedziału 0 do 25
            char[] wynik = new char[tekst.Length];

            for (int i = 0; i < tekst.Length; i++)
            {
                char znak = tekst[i];   //rozbicie napisu na "tablice"

                if (znak >= 'a' && znak <= 'z')
                {
                    wynik[i] = (char)((znak - 'a' + klucz + 26) % 26 + 'a');

                    //wynik[i] = (char)( ... ) zapewnia konwersje do typu char
                    // znak - 'a'   zapewnia zamiane znaku na cyfre 'a' - 'a' = 0 , 'b' - 'a' = 1 , 'z' - 'a' = 25
                    // + klucz      przesuwa o podany klucz 'a' → 0 + 3 = 3  ,  'x' → 23 + 3 = 26
                    // + 26         zapewnia że liczby będą dodatnie
                    // % 26         zapewnie że liczby nie wydją poza zakres
                    // + 'a'        przywraca spowtorem do liter

                }
                else
                {
                    wynik[i] = znak;
                }
            }

            return new string(wynik);
        }
    }
}