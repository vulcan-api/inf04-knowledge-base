namespace ArkuszCezar.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            string tekst = "abc";
            int klucz = 3;

            string wynik = MainWindow.Szyfruj(tekst, klucz);

            Assert.Equal("def", wynik);
        }
        //kolejne test w analogiczny spos�
    }
}